import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { notebookApi, sectionApi, pageApi } from '../services/api';

// Represent an empty TipTap document as JSON string so the editor can reliably
// detect and set an empty document instead of ignoring empty-string updates.
const EMPTY_TIPTAP_DOC = JSON.stringify({ type: 'doc', content: [] });

const AppContext = createContext();

const storedSidebarPref = (() => {
  try {
    const v = localStorage.getItem('sidebarOpen');
    if (v === 'true') return true;
    if (v === 'false') return false;
    return null;
  } catch (_) { return null; }
})();

const initialState = {
  notebooks: [],
  sections: [],
  pages: [],
  calendarOpen: false,
  currentNotebook: null,
  currentSection: null,
  currentPage: null,
  loading: false,
  error: null,
  darkMode: localStorage.getItem('darkMode') === 'true',
  // If user has a stored preference use it; otherwise fall back to desktop breakpoint default
  sidebarOpen: storedSidebarPref !== null ? storedSidebarPref : (window.innerWidth >= 1024),
  // Persist whether the Tabbed Notes view is open so refresh keeps it
  tabbedOpen: (() => { try { const v = localStorage.getItem('tabbedOpen'); if (v === 'true') return true; if (v === 'false') return false; return false; } catch(_) { return false; } })(),
  autosaveStatus: 'saved', // 'saving', 'saved', 'error'
  // Editor font and spacing preferences
  fontFamily: localStorage.getItem('editorFontFamily') || 'Inter, system-ui, sans-serif',
  fontSize: parseInt(localStorage.getItem('editorFontSize')) || 16,
  lineSpacing: parseFloat(localStorage.getItem('editorLineSpacing')) || 1.6,
  spaceBefore: parseInt(localStorage.getItem('editorSpaceBefore')) || 0,
  spaceAfter: parseInt(localStorage.getItem('editorSpaceAfter')) || 0,
};

function appReducer(state, action) {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false };
    
    case 'SET_NOTEBOOKS':
      return { ...state, notebooks: action.payload };
    
    case 'ADD_NOTEBOOK':
      return { ...state, notebooks: [...state.notebooks, action.payload] };
    
    case 'UPDATE_NOTEBOOK':
      return {
        ...state,
        notebooks: state.notebooks.map(nb => 
          nb.id === action.payload.id ? action.payload : nb
        ),
      };
    
    case 'DELETE_NOTEBOOK':
      return {
        ...state,
        notebooks: state.notebooks.filter(nb => nb.id !== action.payload),
        currentNotebook: state.currentNotebook?.id === action.payload ? null : state.currentNotebook,
      };
    
    case 'SET_CURRENT_NOTEBOOK':
      return { ...state, currentNotebook: action.payload, currentSection: null, currentPage: null };
    
    case 'SET_SECTIONS':
      return { ...state, sections: action.payload };
    
    case 'ADD_SECTION':
      return { ...state, sections: [...state.sections, action.payload] };
    
    case 'UPDATE_SECTION':
      return {
        ...state,
        sections: state.sections.map(section => 
          section.id === action.payload.id ? action.payload : section
        ),
      };
    
    case 'DELETE_SECTION':
      return {
        ...state,
        sections: state.sections.filter(section => section.id !== action.payload),
        currentSection: state.currentSection?.id === action.payload ? null : state.currentSection,
      };
    
    case 'SET_CURRENT_SECTION':
      return { ...state, currentSection: action.payload, currentPage: null };
    
    case 'SET_PAGES':
      return { ...state, pages: action.payload };
    
    case 'ADD_PAGE':
      return { ...state, pages: [...state.pages, action.payload] };
    
    case 'UPDATE_PAGE':
      return {
        ...state,
        pages: state.pages.map(page => 
          page.id === action.payload.id ? action.payload : page
        ),
        currentPage: state.currentPage?.id === action.payload.id ? action.payload : state.currentPage,
      };
    
    case 'DELETE_PAGE':
      return {
        ...state,
        pages: state.pages.filter(page => page.id !== action.payload),
        currentPage: state.currentPage?.id === action.payload ? null : state.currentPage,
      };
    
    case 'SET_CURRENT_PAGE':
      return { ...state, currentPage: action.payload };
    
    case 'TOGGLE_DARK_MODE':
      const newDarkMode = !state.darkMode;
      localStorage.setItem('darkMode', newDarkMode.toString());
      return { ...state, darkMode: newDarkMode };
    
    case 'TOGGLE_SIDEBAR': {
      const next = !state.sidebarOpen;
      try { localStorage.setItem('sidebarOpen', next.toString()); } catch(_) {}
      return { ...state, sidebarOpen: next };
    }

    case 'TOGGLE_CALENDAR':
      return { ...state, calendarOpen: !state.calendarOpen };

    case 'TOGGLE_TABBED': {
      const next = !state.tabbedOpen;
      try { localStorage.setItem('tabbedOpen', next.toString()); } catch(_) {}
      return { ...state, tabbedOpen: next };
    }

    case 'SET_TABBED_OPEN': {
      try { localStorage.setItem('tabbedOpen', action.payload.toString()); } catch(_) {}
      return { ...state, tabbedOpen: action.payload };
    }

    case 'SET_CALENDAR_OPEN':
      return { ...state, calendarOpen: action.payload };
    
    case 'SET_SIDEBAR_OPEN': {
      try { localStorage.setItem('sidebarOpen', action.payload.toString()); } catch(_) {}
      return { ...state, sidebarOpen: action.payload };
    }
    
    case 'SET_AUTOSAVE_STATUS':
      return { ...state, autosaveStatus: action.payload };
    
    case 'SET_FONT_FAMILY': {
      try { localStorage.setItem('editorFontFamily', action.payload); } catch(_) {}
      return { ...state, fontFamily: action.payload };
    }
    
    case 'SET_FONT_SIZE': {
      const size = Math.max(10, Math.min(32, action.payload)); // Clamp between 10px and 32px
      try { localStorage.setItem('editorFontSize', size.toString()); } catch(_) {}
      return { ...state, fontSize: size };
    }
    
    case 'SET_LINE_SPACING': {
      const spacing = Math.max(1.0, Math.min(3.0, action.payload)); // Clamp between 1.0 and 3.0
      try { localStorage.setItem('editorLineSpacing', spacing.toString()); } catch(_) {}
      return { ...state, lineSpacing: spacing };
    }
    
    case 'SET_SPACE_BEFORE': {
      const space = Math.max(0, Math.min(50, action.payload)); // Clamp between 0px and 50px
      try { localStorage.setItem('editorSpaceBefore', space.toString()); } catch(_) {}
      return { ...state, spaceBefore: space };
    }
    
    case 'SET_SPACE_AFTER': {
      const space = Math.max(0, Math.min(50, action.payload)); // Clamp between 0px and 50px
      try { localStorage.setItem('editorSpaceAfter', space.toString()); } catch(_) {}
      return { ...state, spaceAfter: space };
    }
    
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Apply dark mode class to document
  useEffect(() => {
    if (state.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.darkMode]);

  // Load initial data
  useEffect(() => {
    loadNotebooks();
  }, []);

  // Load sections when notebook changes
  useEffect(() => {
    if (state.currentNotebook) {
      loadSections(state.currentNotebook.id);
    } else {
      dispatch({ type: 'SET_SECTIONS', payload: [] });
    }
  }, [state.currentNotebook]);

  // Load pages when section changes
  useEffect(() => {
    if (state.currentSection) {
      loadPages(state.currentSection.id);
    } else {
      dispatch({ type: 'SET_PAGES', payload: [] });
    }
  }, [state.currentSection]);

  const loadNotebooks = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      const response = await notebookApi.getAll();
      dispatch({ type: 'SET_NOTEBOOKS', payload: response.data });
      
      // Auto-select first notebook if none selected
      if (response.data.length > 0 && !state.currentNotebook) {
        dispatch({ type: 'SET_CURRENT_NOTEBOOK', payload: response.data[0] });
      }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const loadSections = async (notebookId) => {
    try {
      const response = await sectionApi.getByNotebook(notebookId);
      dispatch({ type: 'SET_SECTIONS', payload: response.data });
      
      // Auto-select first section if none selected
      if (response.data.length > 0 && !state.currentSection) {
        dispatch({ type: 'SET_CURRENT_SECTION', payload: response.data[0] });
      }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
    }
  };

  const loadPages = async (sectionId) => {
    try {
      const response = await pageApi.getBySection(sectionId);
  // Ensure pages list and auto-selected page have a normalized empty doc
  // for pages that have no content on disk (empty string/null).
  const normalized = response.data.map(p => ({ ...p, content: p.content && p.content !== '' ? p.content : EMPTY_TIPTAP_DOC }));
  dispatch({ type: 'SET_PAGES', payload: normalized });
      
      // Auto-select first page if none selected
      if (normalized.length > 0 && !state.currentPage) {
        // Use in-memory page object directly (avoid extra fetch that can reset editor caret)
        // Ensure the selected page has normalized content so the editor clears properly.
        dispatch({ type: 'SET_CURRENT_PAGE', payload: normalized[0] });
      }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
    }
  };

  const createNotebook = async (name) => {
    try {
      const response = await notebookApi.create(name);
      dispatch({ type: 'ADD_NOTEBOOK', payload: response.data });
      dispatch({ type: 'SET_CURRENT_NOTEBOOK', payload: response.data });
      return response.data;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const createSection = async (name) => {
    if (!state.currentNotebook) return;
    
    try {
      const response = await sectionApi.create(state.currentNotebook.id, name);
      dispatch({ type: 'ADD_SECTION', payload: response.data });
      dispatch({ type: 'SET_CURRENT_SECTION', payload: response.data });
      return response.data;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const createPage = async (title = 'Untitled Page') => {
    if (!state.currentSection) return;
    
    try {
      const response = await pageApi.create(state.currentSection.id, title, '');
  // Normalize created page content to an explicit empty TipTap doc so the editor
  // will receive a JSON doc string and correctly reset instead of keeping prior content.
  const pageData = { ...response.data };
  if (!pageData.content || pageData.content === '') pageData.content = EMPTY_TIPTAP_DOC;
  dispatch({ type: 'ADD_PAGE', payload: pageData });
  // Use the creation response directly (already contains full data)
  dispatch({ type: 'SET_CURRENT_PAGE', payload: pageData });
  return pageData;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const updatePage = async (id, updates) => {
    try {
      dispatch({ type: 'SET_AUTOSAVE_STATUS', payload: 'saving' });
      const response = await pageApi.update(id, updates);
      dispatch({ type: 'UPDATE_PAGE', payload: response.data });
      dispatch({ type: 'SET_AUTOSAVE_STATUS', payload: 'saved' });
      return response.data;
    } catch (error) {
      dispatch({ type: 'SET_AUTOSAVE_STATUS', payload: 'error' });
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const deleteNotebook = async (id) => {
    try {
      await notebookApi.delete(id);
      dispatch({ type: 'DELETE_NOTEBOOK', payload: id });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const deleteSection = async (id) => {
    try {
      await sectionApi.delete(id);
      dispatch({ type: 'DELETE_SECTION', payload: id });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const deletePage = async (id) => {
    try {
      await pageApi.delete(id);
      dispatch({ type: 'DELETE_PAGE', payload: id });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const reorderSections = async (sections) => {
    if (!state.currentNotebook) return;
    
    try {
      const response = await sectionApi.reorder(state.currentNotebook.id, sections);
      dispatch({ type: 'SET_SECTIONS', payload: response.data });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const reorderPages = async (pages) => {
    if (!state.currentSection) return;
    
    try {
      const response = await pageApi.reorder(state.currentSection.id, pages);
      dispatch({ type: 'SET_PAGES', payload: response.data });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const toggleSectionPin = async (id, isPinned) => {
    try {
      const response = await sectionApi.update(id, { is_pinned: isPinned });
      dispatch({ type: 'UPDATE_SECTION', payload: response.data });
      // Reload sections to get proper ordering
      await loadSections(state.currentNotebook.id);
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const togglePagePin = async (id, isPinned) => {
    try {
      const response = await pageApi.update(id, { is_pinned: isPinned });
      dispatch({ type: 'UPDATE_PAGE', payload: response.data });
      // Reload pages to get proper ordering
      await loadPages(state.currentSection.id);
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const selectPage = async (page) => {
  // Directly set current page without refetch to keep editor cursor stable.
  // If you later restrict list endpoints from returning full content for protected pages,
  // add conditional fetch here only for locked pages.
  dispatch({ type: 'SET_CURRENT_PAGE', payload: page });
  };

  const value = {
    state,
    dispatch,
    // Actions
    loadNotebooks,
    createNotebook,
    createSection,
    createPage,
    updatePage,
    selectPage,
    deleteNotebook,
    deleteSection,
    deletePage,
    reorderSections,
    reorderPages,
    toggleSectionPin,
    togglePagePin,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
