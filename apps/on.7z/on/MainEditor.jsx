import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import RichTextEditor from './RichTextEditor';
import PagePasswordModal from './PagePasswordModal';
import apiService, { searchApi,pageApi } from '../services/api';
import { Save, Clock, AlertCircle, Menu, Moon, Sun, Search, Edit2, Lock, LogOut, User } from 'lucide-react';

const MainEditor = () => {
  const { state, dispatch, updatePage } = useApp();
  const { user, logout } = useAuth();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchTimeoutRef = useRef(null);
  const lastSearchTermRef = useRef(null); // store last search term for highlighting after navigation/unlock
  const prevSentSearchRef = useRef(''); // avoid duplicate identical search API calls
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [isPageLocked, setIsPageLocked] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const titleRef = useRef(null);
  const [isEditorFocused, setIsEditorFocused] = useState(true);
  const lastSavedRef = useRef({ title: '', content: '' });
  const [highlightTerm, setHighlightTerm] = useState(''); // term to highlight in editor once page loads
  // Track if we've already fetched protected page content after refresh to avoid duplicate calls
  const fetchedProtectedContentRef = useRef({ pageId: null, fetched: false });
  const rootRef = useRef(null);

  // Update local state when current page changes
  useEffect(() => {
    if (state.currentPage) {
      const pageId = state.currentPage.id;
      const unlockData = sessionStorage.getItem(`unlocked_${pageId}`);
      let isUnlockedInSession = false;
      
      if (unlockData) {
        try {
          const parsed = JSON.parse(unlockData);
          // Check if unlock is still valid (expires after 8 hours)
          isUnlockedInSession = parsed.unlocked && new Date() < new Date(parsed.expires);
        } catch (e) {
          // Legacy format - just check boolean
          isUnlockedInSession = unlockData === 'true';
        }
      }
      
      if (state.currentPage.is_password_protected) {
        if (!isUnlockedInSession) {
          // Locked state – hide content visually but keep existing page data in context (do NOT wipe state.currentPage.content)
          setIsPageLocked(true);
          setTitle(state.currentPage.title || '');
          setContent('');
          // Reset fetched flag for this page so when user unlocks (or session later valid) we can fetch once
          fetchedProtectedContentRef.current = { pageId, fetched: false };
          lastSavedRef.current = { title: state.currentPage.title || '', content: '' };
        } else {
          // Session says it's unlocked (refresh scenario)
          setIsPageLocked(false);
          setTitle(state.currentPage.title || '');

            // If we have no usable content locally, fetch exactly once
          const existingContent = state.currentPage.content;
          const isEmpty = !existingContent || existingContent === '{}' || existingContent === '""' || (typeof existingContent === 'string' && existingContent.trim() === '');
          const needFetch = isEmpty && (!fetchedProtectedContentRef.current.fetched || fetchedProtectedContentRef.current.pageId !== pageId);

          if (needFetch) {
            fetchedProtectedContentRef.current = { pageId, fetched: true };
            pageApi.getById(pageId)
              .then(res => {
                let pc = res.data.content || '';
                if (typeof pc === 'string' && pc.startsWith('{')) {
                  try { pc = JSON.parse(pc); } catch (_) { /* keep string */ }
                }
                setContent(pc);
                // Update context with real content so subsequent renders don't refetch
                dispatch({ type: 'SET_CURRENT_PAGE', payload: { ...state.currentPage, content: pc } });
                // Update lastSavedRef to prevent immediate autosave
                lastSavedRef.current = { 
                  title: state.currentPage.title || '', 
                  content: typeof pc === 'string' ? pc : JSON.stringify(pc || '') 
                };
              })
              .catch(err => {
                // Protected content fetch failed; fallback to blank but keep UI responsive
                setContent('');
              });
          } else {
            // Use existing content
            let pc = existingContent || '';
            if (typeof pc === 'string' && pc.startsWith('{')) {
              try { pc = JSON.parse(pc); } catch (_) { /* ignore */ }
            }
            setContent(pc);
            lastSavedRef.current = { 
              title: state.currentPage.title || '', 
              content: typeof pc === 'string' ? pc : JSON.stringify(pc || '') 
            };
          }
        }
      } else {
        // Not password protected
        setIsPageLocked(false);
        setTitle(state.currentPage.title || '');
        let pageContent = state.currentPage.content || '';
        if (typeof pageContent === 'string' && pageContent.startsWith('{')) {
          try { pageContent = JSON.parse(pageContent); } catch (_) { /* ignore */ }
        }
        setContent(pageContent);
        fetchedProtectedContentRef.current = { pageId: null, fetched: false };
        
        // Update lastSavedRef when page changes to prevent immediate autosave
        lastSavedRef.current = { 
          title: state.currentPage.title || '', 
          content: typeof pageContent === 'string' ? pageContent : JSON.stringify(pageContent || '') 
        };
      }
    } else {
      setTitle('');
      setContent('');
      setIsPageLocked(false);
      lastSavedRef.current = { title: '', content: '' };
    }
  }, [state.currentPage]);

  // Debounced autosave
  useEffect(() => {
    if (!state.currentPage) {
      return;
    }
    
    // Critical: Never autosave if page is password protected and we're in locked state
    // or if the page is password protected and content is empty (likely locked state)
    if (state.currentPage.is_password_protected && (isPageLocked || !content || content === '')) {
      return;
    }

    // Skip if editor not focused
    if (!isEditorFocused) return;

    // Normalize content for comparison (both as strings)
    const currentContentStr = typeof content === 'string' ? content : JSON.stringify(content || '');
    const savedContentStr = lastSavedRef.current.content || '';
    
    const changed = (title !== lastSavedRef.current.title) || (currentContentStr !== savedContentStr);
    if (!changed) {
      return; // nothing new since last save
    }

    const timeoutId = setTimeout(() => {
      updatePage(state.currentPage.id, { title, content });
      lastSavedRef.current = { title, content: currentContentStr };
    }, 1200); // slightly longer debounce to reduce frequency

    return () => clearTimeout(timeoutId);
  }, [title, content, state.currentPage?.id, isPageLocked, isEditorFocused]); // Remove updatePage and use only currentPage.id

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleContentChange = useCallback((newContent) => {
    setContent(newContent);
    // Don't update lastSavedRef here - let autosave effect handle it after actual save
  }, []);

  const handleUnlockPage = (pageData) => {
    // Parse content if it's a JSON string
    let pageContent = pageData.content || '';
    if (typeof pageContent === 'string' && pageContent.startsWith('{')) {
      try {
        pageContent = JSON.parse(pageContent);
      } catch (e) {
        // Keep as string if parsing fails
      }
    }
    
    setContent(pageContent);
    setIsPageLocked(false);
    setShowPasswordModal(false);
    
    // Store unlock state in session storage with expiration (8 hours)
    const unlockData = {
      unlocked: true,
      expires: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString()
    };
    sessionStorage.setItem(`unlocked_${pageData.id}`, JSON.stringify(unlockData));
    // Persist unlock token if provided
    if (pageData.unlockToken) {
      apiService.storePageUnlockToken(pageData.id, pageData.unlockToken);
    }
    
    // Update the current page in context with unlocked data
    dispatch({ type: 'SET_CURRENT_PAGE', payload: { ...pageData, content: pageContent } });

    // If we had a pending search term (from selecting a result on a locked page) highlight now
    if (lastSearchTermRef.current) {
      setHighlightTerm(lastSearchTermRef.current);
    }
  };

  const handlePasswordModalClose = () => {
    setShowPasswordModal(false);
    // If the page is password protected and user cancels, keep it locked
    if (state.currentPage?.is_password_protected) {
      setIsPageLocked(true);
    }
  };

  const handleUnlockButtonClick = () => {
    setShowPasswordModal(true);
  };

  const handleChangePasswordModalClose = () => {
    setShowChangePasswordModal(false);
  };

  const handleLockPage = () => {
    if (state.currentPage) {
  // Initiate lock sequence
      
      // IMPORTANT: Before locking, ensure current content is saved to database
      // This prevents content loss when locking
      if (content && content !== '' && content !== state.currentPage.content) {
  // Save latest content before locking to prevent loss
        updatePage(state.currentPage.id, { title, content });
      }
      
      // Remove unlock status from session storage
      sessionStorage.removeItem(`unlocked_${state.currentPage.id}`);
  apiService.clearPageUnlockToken(state.currentPage.id);
      setIsPageLocked(true);
      
      // Don't clear content from state immediately - keep it for a moment
      // to ensure autosave doesn't run with empty content
    }
  };

  const handlePasswordChange = async (newPasswordData) => {
    // The password modal will handle the API call
    setShowChangePasswordModal(false);
    // No need to refresh - the page will remain unlocked with new password
  };

  // Clear session storage when page becomes protected
  useEffect(() => {
    if (state.currentPage?.is_password_protected) {
      const pageId = state.currentPage.id;
      const unlockData = sessionStorage.getItem(`unlocked_${pageId}`);
      let isUnlockedInSession = false;
      
      if (unlockData) {
        try {
          const parsed = JSON.parse(unlockData);
          isUnlockedInSession = parsed.unlocked && new Date() < new Date(parsed.expires);
        } catch (e) {
          isUnlockedInSession = unlockData === 'true';
        }
      }
      
      if (!isUnlockedInSession) {
        setIsPageLocked(true);
      }
    }
  }, [state.currentPage?.is_password_protected]);

  // Debounced search
  useEffect(() => {
    if (!searchQuery || searchQuery.trim().length < 2) {
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }
    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    searchTimeoutRef.current = setTimeout(async () => {
      try {
        const q = searchQuery.trim();
        if (prevSentSearchRef.current === q) return; // skip duplicate
        prevSentSearchRef.current = q;
        const res = await searchApi.search(q);
        setSearchResults(res.data);
        setShowSearchResults(true);
      } catch (e) {
        // Search failed silently
      }
    }, 400);
  }, [searchQuery]);

  const handleSearchSelect = async (result) => {
    const term = searchQuery.trim();
    lastSearchTermRef.current = term || null;
    setShowSearchResults(false);
    setSearchQuery('');
    
    // Switch notebook & section if different
    if (state.currentNotebook?.id !== result.notebook_id) {
      const targetNotebook = state.notebooks.find(nb => nb.id === result.notebook_id);
      if (targetNotebook) {
        dispatch({ type: 'SET_CURRENT_NOTEBOOK', payload: targetNotebook });
      }
    }
    
    if (state.currentSection?.id !== result.section_id) {
      // Wait for sections to load if switching notebooks
      await new Promise(resolve => {
        const checkSections = () => {
          const sec = state.sections.find(s => s.id === result.section_id);
          if (sec) {
            dispatch({ type: 'SET_CURRENT_SECTION', payload: sec });
            resolve();
          } else {
            setTimeout(checkSections, 100);
          }
        };
        checkSections();
      });
    }
    
    // Wait for pages to load if switching sections, then select page
    await new Promise(resolve => {
      const checkPages = () => {
        const page = state.pages.find(p => p.id === result.id);
        if (page) {
          // Use the full page object from state.pages instead of search result
          dispatch({ type: 'SET_CURRENT_PAGE', payload: page });
          resolve();
        } else {
          setTimeout(checkPages, 100);
        }
      };
      checkPages();
    });
    
    // Set highlight after navigation is complete
    if (!result.is_password_protected && lastSearchTermRef.current) {
      setTimeout(() => {
        setHighlightTerm(lastSearchTermRef.current);
      }, 200);
    }
  };  const handleTitleDoubleClick = () => {
    setIsEditingTitle(true);
    setTimeout(() => {
      if (titleRef.current) {
        titleRef.current.focus();
        titleRef.current.select();
      }
    }, 0);
  };

  const handleTitleKeyPress = (e) => {
    if (e.key === 'Enter') {
      setIsEditingTitle(false);
    }
  };

  const handleTitleBlur = () => {
    setIsEditingTitle(false);
  };

  const getAutosaveIcon = () => {
    switch (state.autosaveStatus) {
      case 'saving':
        return <Clock size={16} className="animate-spin" />;
      case 'saved':
        return <Save size={16} className="text-green-500" />;
      case 'error':
        return <AlertCircle size={16} className="text-red-500" />;
      default:
        return <Save size={16} />;
    }
  };

  const getAutosaveText = () => {
    switch (state.autosaveStatus) {
      case 'saving':
        return 'Saving...';
      case 'saved':
        return 'All changes saved';
      case 'error':
        return 'Error saving';
      default:
        return 'Ready';
    }
  };

  // Keyboard navigation for pages (ArrowUp/ArrowDown)
  useEffect(() => {
    const handler = (e) => {
      // Ignore if modifier keys or typing in input/textarea or contenteditable
      if (e.altKey || e.metaKey || e.ctrlKey || e.shiftKey) return;
      const active = document.activeElement;
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)) return;
      if (!state.currentPage || state.pages.length === 0) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        const idx = state.pages.findIndex(p => p.id === state.currentPage.id);
        if (idx === -1) return;
        let targetIdx = idx;
        if (e.key === 'ArrowDown' && idx < state.pages.length - 1) targetIdx = idx + 1;
        if (e.key === 'ArrowUp' && idx > 0) targetIdx = idx - 1;
        if (targetIdx !== idx) {
          const targetPage = state.pages[targetIdx];
          dispatch({ type: 'SET_CURRENT_PAGE', payload: targetPage });
          // Prevent arrow from scrolling page
          e.preventDefault();
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [state.currentPage, state.pages, dispatch]);

  return (
    <div ref={rootRef} className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Top Bar */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            {/* Mobile menu button */}
            <button
              onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
              className="lg:hidden p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <Menu size={20} />
            </button>

            {/* Page Title - Editable */}
            {state.currentPage ? (
              <div className="flex items-center gap-2 flex-1">
                {isEditingTitle ? (
                  <input
                    ref={titleRef}
                    type="text"
                    value={title}
                    onChange={handleTitleChange}
                    onKeyPress={handleTitleKeyPress}
                    onBlur={handleTitleBlur}
                    className="text-lg font-semibold bg-transparent border-none outline-none text-gray-900 dark:text-white flex-1 min-w-0"
                  />
                ) : (
                  <div 
                    className="flex items-center gap-2 cursor-pointer flex-1 min-w-0"
                    onDoubleClick={handleTitleDoubleClick}
                    title="Double-click to edit"
                  >
                    <h1 className="text-lg font-semibold text-gray-900 dark:text-white truncate">
                      {title || 'Untitled Page'}
                    </h1>
                    <Edit2 size={14} className="text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                )}
              </div>
            ) : (
              <h1 className="text-lg font-semibold text-gray-900 dark:text-white">
                OpenNotes
              </h1>
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Font selector */}
            <select
              value={state.fontFamily}
              onChange={(e) => dispatch({ type: 'SET_FONT_FAMILY', payload: e.target.value })}
              className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700"
              title="Select font"
            >
              <option value="Inter, system-ui, sans-serif">Inter (Default)</option>
              <option value="Georgia, serif">Georgia</option>
              <option value="'Times New Roman', serif">Times New Roman</option>
              <option value="Arial, sans-serif">Arial</option>
              <option value="Helvetica, sans-serif">Helvetica</option>
              <option value="'Courier New', monospace">Courier New</option>
              <option value="Verdana, sans-serif">Verdana</option>
              <option value="'Comic Sans MS', cursive">Comic Sans</option>
            </select>

            {/* Line spacing controls */}
            <div className="flex items-center gap-1 border border-gray-300 dark:border-gray-600 rounded px-2 py-1">
              <button
                onClick={() => dispatch({ type: 'SET_LINE_SPACING', payload: state.lineSpacing - 0.1 })}
                className="px-2 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
                title="Decrease spacing"
              >
                −
              </button>
              <span className="text-xs text-gray-600 dark:text-gray-400 min-w-[2.5rem] text-center">
                {state.lineSpacing.toFixed(1)}
              </span>
              <button
                onClick={() => dispatch({ type: 'SET_LINE_SPACING', payload: state.lineSpacing + 0.1 })}
                className="px-2 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
                title="Increase spacing"
              >
                +
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..."
                className="pl-9 pr-4 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 w-48"
              />
              {showSearchResults && searchResults.length > 0 && (
                <div className="absolute z-20 mt-1 w-96 max-h-80 overflow-y-auto bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded shadow-lg p-2 text-sm">
                  {searchResults.map(r => (
                    <button
                      key={r.id + '-' + r.updated_at}
                      onClick={() => handleSearchSelect(r)}
                      className="w-full text-left px-2 py-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 flex flex-col gap-1"
                    >
                      <span className="font-medium text-gray-900 dark:text-gray-100 truncate">{r.title || 'Untitled Page'}{r.is_password_protected ? ' 🔒' : ''}</span>
                      <span className="text-xs text-gray-500 dark:text-gray-400 truncate">Notebook: {r.notebook_name} / Section: {r.section_name}</span>
                      {!r.is_password_protected && r.content && (
                        <span className="text-xs text-gray-400 dark:text-gray-500 truncate">{r.content.replace(/<[^>]*>/g,'').slice(0,120)}</span>
                      )}
                    </button>
                  ))}
                  {searchResults.length === 50 && (
                    <div className="text-[10px] text-gray-400 px-2 pt-1">Showing first 50 results… refine query</div>
                  )}
                </div>
              )}
            </div>

            {/* Autosave status */}
            <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
              {getAutosaveIcon()}
              <span className="hidden sm:inline">{getAutosaveText()}</span>
            </div>

            {/* Dark mode toggle */}
            <button
              onClick={() => dispatch({ type: 'TOGGLE_DARK_MODE' })}
              className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
              title="Toggle dark mode"
            >
              {state.darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-2 p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                title="User menu"
              >
                <User size={18} />
                <span className="hidden sm:inline text-sm font-medium text-gray-700 dark:text-gray-300">
                  {user?.username}
                </span>
              </button>

              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded shadow-lg z-10 min-w-48">
                  <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {user?.username}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Signed in
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900 flex items-center space-x-2"
                  >
                    <LogOut size={16} />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 overflow-hidden">
        {state.currentPage ? (
          isPageLocked ? (
            // Locked Page View
            <div className="flex-1 flex items-center justify-center p-6">
              <div className="text-center max-w-md">
                <div className="mb-6">
                  <div className="mx-auto w-16 h-16 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                    <Lock className="w-8 h-8 text-red-600 dark:text-red-400" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Page is Protected
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  This page is password protected. Enter the correct password to view its content.
                </p>
                <button
                  onClick={handleUnlockButtonClick}
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <Lock size={16} />
                  <span>Unlock Page</span>
                </button>
              </div>
            </div>
          ) : (
            // Normal Editor View
            <div className="h-full flex flex-col">
              {/* Password Management Bar - Show only if page is password protected but unlocked */}
              {!!state.currentPage.is_password_protected && !isPageLocked ? (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border-b border-yellow-200 dark:border-yellow-800 px-6 py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lock size={16} className="text-yellow-600 dark:text-yellow-400" />
                      <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                        This page is password protected
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowChangePasswordModal(true)}
                        className="text-sm px-3 py-1 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-100 dark:hover:bg-yellow-800 rounded border border-yellow-300 dark:border-yellow-600"
                      >
                        Change Password
                      </button>
                      <button
                        onClick={handleLockPage}
                        className="text-sm px-3 py-1 bg-yellow-600 text-white hover:bg-yellow-700 rounded"
                      >
                        Lock Page
                      </button>
                    </div>
                  </div>
                </div>
              ) : null}
              
              {/* Rich Text Editor - Full Height */}
              <div className="flex-1 p-6 overflow-y-auto">
                <div className="max-w-none w-full h-full">
                  <div
                    onFocus={() => setIsEditorFocused(true)}
                    onBlur={(e) => {
                      // Only treat as blur if focus left the editor container
                      if (!e.currentTarget.contains(e.relatedTarget)) {
                        setIsEditorFocused(false);
                      }
                    }}
                    className="h-full"
                  >
                    <RichTextEditor
                      content={content}
                      onChange={(val) => {
                        setIsEditorFocused(true); // editing implies focus
                        handleContentChange(val);
                      }}
                      highlightTerm={highlightTerm}
                      placeholder="Start writing your note..."
                    />
                  </div>
                </div>
              </div>
            
              {/* Status Bar */}
              <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-6 py-2">
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {state.currentPage.updated_at && (
                    <>Last modified: {new Date(state.currentPage.updated_at).toLocaleString()}</>
                  )}
                </div>
              </div>
            </div>
          )
        ) : (
          // No page selected
          <div className="h-full flex items-center justify-center">
            <div className="text-center text-gray-500 dark:text-gray-400">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                <Search size={32} className="opacity-50" />
              </div>
              <h3 className="text-lg font-medium mb-2">No page selected</h3>
              <p className="text-sm max-w-sm">
                {state.currentSection 
                  ? "Select a page from the sidebar or create a new one to start writing."
                  : "Create a notebook and section first, then add pages to start taking notes."
                }
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Password Modal */}
      <PagePasswordModal
        isOpen={showPasswordModal}
        onClose={handlePasswordModalClose}
        pageId={state.currentPage?.id}
        onSuccess={handleUnlockPage}
        isSettingPassword={false}
      />

      {/* Change Password Modal */}
      <PagePasswordModal
        isOpen={showChangePasswordModal}
        onClose={handleChangePasswordModalClose}
        pageId={state.currentPage?.id}
        onSuccess={handlePasswordChange}
        isSettingPassword={true}
        isChangingPassword={true}
      />
    </div>
  );
};

export default MainEditor;
