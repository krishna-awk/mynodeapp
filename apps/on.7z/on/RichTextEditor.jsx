import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import TextStyle from '@tiptap/extension-text-style';
import Image from '@tiptap/extension-image';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableHeader from '@tiptap/extension-table-header';
import TableCell from '@tiptap/extension-table-cell';
import Link from '@tiptap/extension-link';
import { useApp } from '../context/AppContext';
import { 
  Bold, 
  Italic, 
  Underline as UnderlineIcon, 
  Strikethrough, 
  List, 
  ListOrdered, 
  Heading1, 
  Heading2, 
  Heading3,
  Quote,
  Code,
  Link as LinkIcon,
  Table as TableIcon,
  Image as ImageIcon
} from 'lucide-react';

// Custom FontSize extension
const FontSize = Extension.create({
  name: 'fontSize',

  addOptions() {
    return {
      types: ['textStyle'],
    };
  },

  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: element => element.style.fontSize || null,
            renderHTML: attributes => {
              if (!attributes.fontSize) {
                return {};
              }
              return {
                style: `font-size: ${attributes.fontSize}`,
              };
            },
          },
        },
      },
    ];
  },

  addCommands() {
    return {
      setFontSize: fontSize => ({ chain }) => {
        return chain()
          .setMark('textStyle', { fontSize })
          .run();
      },
      unsetFontSize: () => ({ chain }) => {
        return chain()
          .setMark('textStyle', { fontSize: null })
          .removeEmptyTextStyle()
          .run();
      },
    };
  },
});

// Custom ParagraphSpacing extension for margin-top and margin-bottom
const ParagraphSpacing = Extension.create({
  name: 'paragraphSpacing',

  addOptions() {
    return {
      types: ['paragraph'],
    };
  },

  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          marginTop: {
            default: null,
            parseHTML: element => element.style.marginTop || null,
            renderHTML: attributes => {
              if (!attributes.marginTop) {
                return {};
              }
              return {
                style: `margin-top: ${attributes.marginTop}`,
              };
            },
          },
          marginBottom: {
            default: null,
            parseHTML: element => element.style.marginBottom || null,
            renderHTML: attributes => {
              if (!attributes.marginBottom) {
                return {};
              }
              return {
                style: `margin-bottom: ${attributes.marginBottom}`,
              };
            },
          },
        },
      },
    ];
  },

  addCommands() {
    return {
      setSpaceBefore: marginTop => ({ commands }) => {
        return commands.updateAttributes('paragraph', { marginTop });
      },
      setSpaceAfter: marginBottom => ({ commands }) => {
        return commands.updateAttributes('paragraph', { marginBottom });
      },
    };
  },
});

const MenuBar = ({ editor }) => {
  const { state, dispatch } = useApp();
  
  if (!editor) {
    return null;
  }

  const addLink = () => {
    const url = window.prompt('Enter URL:');
    if (url) {
      editor.chain().focus().setLink({ href: url }).run();
    }
  };

  const insertTable = () => {
    editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
  };

  const insertImageByUrl = () => {
    const url = window.prompt('Enter Image URL:');
    if (url) {
      editor.chain().focus().setImage({ src: url }).run();
    }
  };

  const insertImageFromFile = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result;
        editor.chain().focus().setImage({ src: base64 }).run();
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };

  const handleFontSizeChange = (size) => {
    const { from, to } = editor.state.selection;
    const hasSelection = from !== to;

    if (hasSelection) {
      // Apply to selected text
      editor.chain().focus().setFontSize(`${size}px`).run();
    } else {
      // Apply to all content
      editor.chain().focus().selectAll().setFontSize(`${size}px`).run();
    }
    
    // Update the context state for UI
    dispatch({ type: 'SET_FONT_SIZE', payload: size });
  };

  const handleSpaceBeforeChange = (space) => {
    const { from, to } = editor.state.selection;
    const hasSelection = from !== to;

    if (hasSelection) {
      // Apply to selected paragraphs
      editor.chain().focus().setSpaceBefore(`${space}px`).run();
    } else {
      // Apply to all paragraphs
      editor.chain().focus().selectAll().setSpaceBefore(`${space}px`).run();
    }
    
    dispatch({ type: 'SET_SPACE_BEFORE', payload: space });
  };

  const handleSpaceAfterChange = (space) => {
    const { from, to } = editor.state.selection;
    const hasSelection = from !== to;

    if (hasSelection) {
      // Apply to selected paragraphs
      editor.chain().focus().setSpaceAfter(`${space}px`).run();
    } else {
      // Apply to all paragraphs
      editor.chain().focus().selectAll().setSpaceAfter(`${space}px`).run();
    }
    
    dispatch({ type: 'SET_SPACE_AFTER', payload: space });
  };

  return (
    <div className="editor-toolbar">
      {/* Font size selector */}
      <select
        value={state.fontSize}
        onChange={(e) => handleFontSizeChange(parseInt(e.target.value))}
        className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 mr-2"
        title="Font size"
      >
        <option value="10">10px</option>
        <option value="12">12px</option>
        <option value="14">14px</option>
        <option value="16">16px (Default)</option>
        <option value="18">18px</option>
        <option value="20">20px</option>
        <option value="22">22px</option>
        <option value="24">24px</option>
        <option value="28">28px</option>
        <option value="32">32px</option>
      </select>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={() => editor.chain().focus().toggleBold().run()}
        className={editor.isActive('bold') ? 'is-active' : ''}
        title="Bold"
      >
        <Bold size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleItalic().run()}
        className={editor.isActive('italic') ? 'is-active' : ''}
        title="Italic"
      >
        <Italic size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        className={editor.isActive('underline') ? 'is-active' : ''}
        title="Underline"
      >
        <UnderlineIcon size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleStrike().run()}
        className={editor.isActive('strike') ? 'is-active' : ''}
        title="Strikethrough"
      >
        <Strikethrough size={16} />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
        className={editor.isActive('heading', { level: 1 }) ? 'is-active' : ''}
        title="Heading 1"
      >
        <Heading1 size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        className={editor.isActive('heading', { level: 2 }) ? 'is-active' : ''}
        title="Heading 2"
      >
        <Heading2 size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
        className={editor.isActive('heading', { level: 3 }) ? 'is-active' : ''}
        title="Heading 3"
      >
        <Heading3 size={16} />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={editor.isActive('bulletList') ? 'is-active' : ''}
        title="Bullet List"
      >
        <List size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={editor.isActive('orderedList') ? 'is-active' : ''}
        title="Numbered List"
      >
        <ListOrdered size={16} />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={() => editor.chain().focus().toggleBlockquote().run()}
        className={editor.isActive('blockquote') ? 'is-active' : ''}
        title="Quote"
      >
        <Quote size={16} />
      </button>
      
      <button
        onClick={() => editor.chain().focus().toggleCodeBlock().run()}
        className={editor.isActive('codeBlock') ? 'is-active' : ''}
        title="Code Block"
      >
        <Code size={16} />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={addLink}
        className={editor.isActive('link') ? 'is-active' : ''}
        title="Add Link"
      >
        <LinkIcon size={16} />
      </button>
      
      <button
        onClick={insertTable}
        title="Insert Table"
      >
        <TableIcon size={16} />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      <button
        onClick={insertImageByUrl}
        title="Insert Image by URL"
      >
        <ImageIcon size={16} />
      </button>
      <button
        onClick={insertImageFromFile}
        title="Upload Image"
      >
        <ImageIcon size={16} className="opacity-60" />
      </button>

      <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1"></div>

      {/* Space before controls */}
      <div className="flex items-center gap-1 border border-gray-300 dark:border-gray-600 rounded px-2 py-1 mr-1" title="Space before paragraph">
        <span className="text-xs text-gray-500 dark:text-gray-400">Before:</span>
        <button
          onClick={() => handleSpaceBeforeChange(Math.max(0, state.spaceBefore - 2))}
          className="px-1 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          −
        </button>
        <span className="text-xs text-gray-600 dark:text-gray-400 min-w-[2rem] text-center">
          {state.spaceBefore}px
        </span>
        <button
          onClick={() => handleSpaceBeforeChange(Math.min(50, state.spaceBefore + 2))}
          className="px-1 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          +
        </button>
      </div>

      {/* Space after controls */}
      <div className="flex items-center gap-1 border border-gray-300 dark:border-gray-600 rounded px-2 py-1" title="Space after paragraph">
        <span className="text-xs text-gray-500 dark:text-gray-400">After:</span>
        <button
          onClick={() => handleSpaceAfterChange(Math.max(0, state.spaceAfter - 2))}
          className="px-1 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          −
        </button>
        <span className="text-xs text-gray-600 dark:text-gray-400 min-w-[2rem] text-center">
          {state.spaceAfter}px
        </span>
        <button
          onClick={() => handleSpaceAfterChange(Math.min(50, state.spaceAfter + 2))}
          className="px-1 py-0.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          +
        </button>
      </div>
    </div>
  );
};

const RichTextEditor = ({ content, onChange, placeholder = "Start writing...", highlightTerm }) => {
  const { state } = useApp();
  const scrollContainerRef = React.useRef(null);
  const searchTermRef = React.useRef('');
  searchTermRef.current = highlightTerm || '';

  // Search highlight extension using decorations
  const SearchHighlight = React.useMemo(() => Extension.create({
    name: 'searchHighlight',
    addProseMirrorPlugins() {
      const key = new PluginKey('searchHighlight');
      return [
        new Plugin({
          key,
          state: {
            init: () => DecorationSet.empty,
            apply(tr, old) {
              const shouldRecalc = tr.getMeta('searchHighlight') || tr.docChanged;
              if (!shouldRecalc) return old;
              const term = searchTermRef.current.trim().toLowerCase();
              if (!term) return DecorationSet.empty;
              const decos = [];
              tr.doc.descendants((node, pos) => {
                if (!node.isText) return true;
                const lower = node.text.toLowerCase();
                let start = 0;
                while (true) {
                  const idx = lower.indexOf(term, start);
                  if (idx === -1) break;
                  const from = pos + idx;
                  const to = from + term.length;
                  decos.push(Decoration.inline(from, to, { class: 'search-highlight' }));
                  start = idx + term.length;
                }
                return true;
              });
              return DecorationSet.create(tr.doc, decos);
            }
          },
          props: {
            decorations(state) {
              return this.getState(state);
            }
          }
        })
      ];
    }
  }), []);
  // Prepare initial content for the editor: if caller passed a JSON-string, parse it
  let initialContent = '';
  if (content && typeof content === 'object') {
    initialContent = content;
  } else if (typeof content === 'string' && content.trim() !== '') {
    const trimmed = content.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      try {
        initialContent = JSON.parse(trimmed);
      } catch (e) {
        initialContent = content; // leave as string (HTML)
      }
    } else {
      initialContent = content; // plain HTML or text
    }
  }

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      TextStyle,
      FontSize,
      ParagraphSpacing,
      Link.configure({
        openOnClick: false,
      }),
      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
      Image.configure({
        inline: false,
        allowBase64: true,
      }),
      SearchHighlight,
    ],
    content: content || '',
    onUpdate: ({ editor }) => {
      const json = editor.getJSON();
      onChange(JSON.stringify(json));
    },
    editorProps: {
      attributes: {
        // add a stable class so we can scope styles to the editable content
        class: 'editor-content prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none break-words whitespace-pre-wrap',
      },
    },
  });

  // Update editor content when prop changes (preserve cursor position)
  const lastContentRef = React.useRef('');
  React.useEffect(() => {
    if (editor && content !== undefined) {
      try {
        const currentContent = JSON.stringify(editor.getJSON());
        // Normalize incoming content: accept object (already-parsed JSON) or JSON-string
        let incoming = '';
        if (content && typeof content === 'object') {
          incoming = JSON.stringify(content);
        } else if (typeof content === 'string' && content.trim() !== '') {
          incoming = content;
        } else {
          incoming = '';
        }

        if (currentContent !== incoming && incoming !== lastContentRef.current) {
          // Store current selection before content update
          const selection = editor.state.selection;
          let parsedContent = null;
          try {
            parsedContent = incoming ? JSON.parse(incoming) : null;
          } catch (e) {
            // not JSON, keep as-is (HTML/string)
            parsedContent = incoming;
          }

          // If incoming was empty, treat as empty doc and clear
          if (!incoming) {
            editor.commands.clearContent(true);
            editor.commands.setTextSelection(0);
            lastContentRef.current = incoming;
            return;
          }

          // Update content (parsedContent may be an object or string)
          editor.commands.setContent(parsedContent);

          // Restore selection if content change was external (not from user typing)
          if (selection && selection.from !== undefined) {
            // Defer to ensure content is rendered
            setTimeout(() => {
              try {
                const docSize = editor.state.doc.content.size;
                const safeFrom = Math.min(selection.from, docSize);
                const safeTo = Math.min(selection.to || safeFrom, docSize);
                editor.commands.setTextSelection({ from: safeFrom, to: safeTo });
              } catch (e) {
                // If restoration fails, just focus without specific position
                editor.commands.focus();
              }
            }, 10);
          }
          lastContentRef.current = incoming;
        }
      } catch (error) {
        // Fallback for non-JSON content
        const selection = editor.state.selection;
        editor.commands.setContent(content || '');
        if (selection && selection.from !== undefined) {
          setTimeout(() => {
            try {
              const docSize = editor.state.doc.content.size;
              const safeFrom = Math.min(selection.from, docSize);
              editor.commands.setTextSelection(safeFrom);
            } catch (e) {
              editor.commands.focus();
            }
          }, 10);
        }
      }
    }
  }, [content, editor]);

  // Highlight & scroll to first occurrence of highlightTerm
  const highlightAppliedRef = React.useRef(false);
  const [matchIndex, setMatchIndex] = React.useState(0);
  const [matchTotal, setMatchTotal] = React.useState(0);
  const matchesRef = React.useRef([]); // {from,to}
  const scrollToRange = (range) => {
    if (!editor || !range) return;
    editor.commands.setTextSelection(range);
    requestAnimationFrame(() => {
      try {
        const view = editor.view;
        const coords = view.coordsAtPos(range.from);
        const container = scrollContainerRef.current;
        if (container && coords) {
          const cRect = container.getBoundingClientRect();
          const absoluteY = coords.top - cRect.top + container.scrollTop;
          const targetScroll = Math.max(0, absoluteY - container.clientHeight * 0.3);
          container.scrollTo({ top: targetScroll, behavior: 'smooth' });
        }
      } catch (e) {
        const sel = document.getSelection();
        if (sel && sel.rangeCount) {
          sel.getRangeAt(0).startContainer?.parentElement?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    });
  };

  React.useEffect(() => {
    if (!editor || !highlightTerm || !content) {
      matchesRef.current = [];
      setMatchTotal(0);
      setMatchIndex(0);
      highlightAppliedRef.current = false;
      if (editor) {
        editor.view.dispatch(editor.state.tr.setMeta('searchHighlight', { updated: true }));
      }
      return;
    }
    const term = highlightTerm.toLowerCase();
    const list = [];
    editor.state.doc.descendants((node, pos) => {
      if (!node.isText) return true;
      const lower = node.text.toLowerCase();
      let startIdx = 0;
      while (true) {
        const idx = lower.indexOf(term, startIdx);
        if (idx === -1) break;
        list.push({ from: pos + idx, to: pos + idx + highlightTerm.length });
        startIdx = idx + term.length;
      }
      return true;
    });
    matchesRef.current = list;
    setMatchTotal(list.length);
    if (list.length > 0) {
      setMatchIndex(0);
      highlightAppliedRef.current = true;
      scrollToRange(list[0]);
    }
  // trigger decoration recompute
  editor.view.dispatch(editor.state.tr.setMeta('searchHighlight', { updated: true }));
  }, [highlightTerm, editor, content]);

  const gotoMatch = (dir) => {
    if (matchTotal < 1) return;
    let next = matchIndex + dir;
    if (next < 0) next = matchTotal - 1;
    if (next >= matchTotal) next = 0;
    setMatchIndex(next);
    const range = matchesRef.current[next];
    scrollToRange(range);
  };

  // Reset internal flag if new content unrelated to highlightTerm loads (e.g., navigating to another page)
  React.useEffect(() => {
    if (!highlightTerm) {
      highlightAppliedRef.current = false;
      matchesRef.current = [];
      setMatchTotal(0);
      setMatchIndex(0);
      if (editor) {
        editor.view.dispatch(editor.state.tr.setMeta('searchHighlight', { updated: true }));
      }
    }
  }, [highlightTerm]);

  return (
    <div className="h-full w-full border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-900 flex flex-col relative">
  {/* inline style for search highlights (scoped) and editor wrapping rules */}
  <style>{`
    .search-highlight { background: #fde68a; border-radius:2px; padding:0 1px; }
    /* ensure long words and URLs wrap instead of expanding the editor width */
    .editor-content, .editor-content * {
      word-break: break-word;
      overflow-wrap: anywhere;
    }
    /* make sure images and tables scale to editor width */
    .editor-content img { max-width: 100%; height: auto; display: block; }
    .editor-content table { width: 100%; table-layout: auto; }
    /* avoid horizontal scrolling inside editor */
    .editor-content { white-space: pre-wrap; }
  `}</style>
      <MenuBar editor={editor} />
      <div ref={scrollContainerRef} className="flex-1 min-h-0 overflow-y-auto">
        {/*
          EditorContent receives an onClick handler so clicks on <a> can open in a new tab.
          We also give it a minimum height so the editor has a sensible default size.
          Apply fontFamily and lineSpacing from context to the content area.
        */}
        <EditorContent
          editor={editor}
          className="w-full"
          placeholder={placeholder}
          onClick={(e) => {
            try {
              const anchor = e.target.closest && e.target.closest('a');
              if (anchor && anchor.href) {
                // Open in new tab and stop the editor from handling the click
                window.open(anchor.href, '_blank', 'noopener');
                e.preventDefault();
                return;
              }
            } catch (err) {
              // ignore
            }
          }}
          // Apply font and spacing from context
          style={{ 
            minHeight: 320,
            fontFamily: state.fontFamily || 'Inter, system-ui, sans-serif',
            lineHeight: state.lineSpacing || 1.6
          }}
        />
      </div>
      {highlightTerm && matchTotal > 0 && (
        <div className="absolute top-10 right-3 bg-gray-800/80 text-white text-xs px-2 py-1 rounded flex items-center gap-2 select-none">
          <span>{matchIndex + 1}/{matchTotal}</span>
          <button onClick={() => gotoMatch(-1)} className="px-1 hover:bg-gray-700 rounded" title="Previous match">↑</button>
          <button onClick={() => gotoMatch(1)} className="px-1 hover:bg-gray-700 rounded" title="Next match">↓</button>
        </div>
      )}
    </div>
  );
};

export default RichTextEditor;
